import React, { useState, useEffect } from 'react';
import ParticleBackground from './components/ParticleBackground';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import About from './components/About';
import Projects from './components/Projects';
import Contact from './components/Contact';
import AiAssistant from './components/AiAssistant';
import { Section } from './types';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>(Section.HOME);
  const [isScrolling, setIsScrolling] = useState(false);

  const scrollToSection = (section: Section) => {
    setIsScrolling(true);
    const element = document.getElementById(section);
    if (element) {
      const offset = 80; // Height of the sticky navbar
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
      setActiveSection(section);
      
      // Reset scrolling lock after animation to allow scroll spy to resume
      setTimeout(() => setIsScrolling(false), 1000);
    }
  };

  // Update active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (isScrolling) return;

      const sections = Object.values(Section);
      const scrollPosition = window.scrollY + 300; // Trigger point offset

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (
            scrollPosition >= offsetTop &&
            scrollPosition < offsetTop + offsetHeight
          ) {
            setActiveSection(section);
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isScrolling]);

  return (
    <div className="relative min-h-screen text-gray-200 font-sans selection:bg-primary selection:text-dark">
      <ParticleBackground />
      
      <Navigation 
        activeSection={activeSection} 
        scrollToSection={scrollToSection} 
      />
      
      <main className="relative z-10">
        <Hero scrollToSection={scrollToSection} />
        <About />
        <Projects />
        <Contact />
      </main>

      <AiAssistant />
      
      {/* Decorative gradients */}
      <div className="fixed top-0 left-0 w-full h-20 bg-gradient-to-b from-dark to-transparent z-40 pointer-events-none"></div>
      <div className="fixed bottom-0 left-0 w-full h-20 bg-gradient-to-t from-dark to-transparent z-40 pointer-events-none"></div>
    </div>
  );
};

export default App;