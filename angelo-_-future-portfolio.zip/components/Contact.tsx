import React from 'react';
import { Mail, Linkedin, Twitter, Github } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-full bg-gradient-to-b from-primary/5 to-transparent blur-3xl -z-10"></div>

      <div className="max-w-4xl mx-auto px-6 text-center">
        <span className="text-primary font-mono mb-4 block">04 // CONNECT</span>
        <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Collaborate?</h2>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto mb-12">
          Visit my main portfolio to see my availability and full contact details, or simply drop me a line here.
        </p>

        <a 
          href="mailto:angelo@example.com" 
          className="inline-block px-8 py-4 border border-primary text-primary font-bold rounded hover:bg-primary hover:text-dark transition-all duration-300 shadow-[0_0_20px_rgba(0,240,255,0.2)] hover:shadow-[0_0_40px_rgba(0,240,255,0.4)]"
        >
          SEND EMAIL
        </a>

        <div className="mt-8">
             <a 
                href="https://angeloportfolio.vercel.app/" 
                target="_blank"
                rel="noreferrer"
                className="text-sm text-gray-500 hover:text-primary underline decoration-primary/30 underline-offset-4 transition-colors"
            >
                Visit angeloportfolio.vercel.app
            </a>
        </div>

        <div className="mt-20 flex justify-center gap-8">
          <a href="#" className="text-gray-400 hover:text-primary transition-colors hover:-translate-y-1 transform duration-200">
            <Github className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-primary transition-colors hover:-translate-y-1 transform duration-200">
            <Linkedin className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-primary transition-colors hover:-translate-y-1 transform duration-200">
            <Twitter className="w-6 h-6" />
          </a>
          <a href="#" className="text-gray-400 hover:text-primary transition-colors hover:-translate-y-1 transform duration-200">
            <Mail className="w-6 h-6" />
          </a>
        </div>

        <div className="mt-12 text-sm text-gray-600 font-mono">
          <p>DESIGNED & BUILT BY ANGELO</p>
        </div>
      </div>
    </section>
  );
};

export default Contact;