import React from 'react';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center gap-4 mb-8">
            <span className="text-primary font-mono text-xl">02 //</span>
            <h2 className="text-3xl md:text-4xl font-bold">ABOUT ME</h2>
            <div className="h-[1px] flex-grow bg-gray-800"></div>
          </div>

          <div className="grid md:grid-cols-5 gap-12">
            <div className="md:col-span-3 space-y-6 text-gray-300 leading-relaxed text-lg">
              <p>
                Hello! I'm Angelo, a passionate developer based in France. My journey in web development began with a curiosity for how things work on the screen, which evolved into a career crafting digital interfaces.
              </p>
              <p>
                I specialize in <span className="text-primary">React ecosystem</span>. I love bridging the gap between design and engineering—building things that look great and perform even better under the hood.
              </p>
              <p>
                Currently, I'm exploring the world of AI integration and WebGL to push the boundaries of what a static website can be.
              </p>
            </div>
            
            <div className="md:col-span-2">
              <div className="glass-panel p-6 rounded-lg relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary rounded-lg opacity-20 blur group-hover:opacity-40 transition-opacity"></div>
                <h3 className="text-xl font-bold mb-4 relative z-10">Tech Arsenal</h3>
                <ul className="space-y-2 relative z-10">
                  {['JavaScript (ES6+)', 'TypeScript', 'React', 'Next.js', 'Tailwind CSS', 'Framer Motion', 'Node.js', 'Git'].map((tech) => (
                    <li key={tech} className="flex items-center gap-2 text-sm text-gray-400 font-mono">
                      <span className="text-primary">▹</span> {tech}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;