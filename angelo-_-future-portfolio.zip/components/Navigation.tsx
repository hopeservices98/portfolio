import React, { useState, useEffect } from 'react';
import { Menu, X, Terminal } from 'lucide-react';
import { Section } from '../types';

interface NavigationProps {
  activeSection: Section;
  scrollToSection: (section: Section) => void;
}

const Navigation: React.FC<NavigationProps> = ({ activeSection, scrollToSection }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: Section.HOME, label: '01 // HOME' },
    { id: Section.ABOUT, label: '02 // ABOUT' },
    { id: Section.PROJECTS, label: '03 // WORKS' },
    { id: Section.CONTACT, label: '04 // CONTACT' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'glass-panel py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => scrollToSection(Section.HOME)}
        >
          <div className="p-2 border border-primary/30 rounded group-hover:border-primary transition-colors">
             <Terminal className="text-primary w-6 h-6" />
          </div>
          <span className="font-mono text-xl font-bold tracking-tighter text-white">
            ANGELO<span className="text-primary">.DEV</span>
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex gap-8">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className={`font-mono text-sm tracking-widest transition-all duration-300 hover:text-primary relative group ${
                activeSection === item.id ? 'text-primary' : 'text-gray-400'
              }`}
            >
              {item.label}
              <span className={`absolute -bottom-2 left-0 h-[1px] bg-primary transition-all duration-300 ${
                activeSection === item.id ? 'w-full' : 'w-0 group-hover:w-full'
              }`} />
            </button>
          ))}
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-white"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="absolute top-full left-0 w-full glass-panel border-t border-gray-800 p-6 md:hidden flex flex-col gap-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                scrollToSection(item.id);
                setIsOpen(false);
              }}
              className={`text-left font-mono text-lg ${
                 activeSection === item.id ? 'text-primary' : 'text-gray-300'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
};

export default Navigation;